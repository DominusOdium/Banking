#include <iostream>
#include "savings.h"
using namespace std;

int main() {
	while (1) {
		cout << "*************************************" << endl;
		cout << "************Data Input***************" << endl;
		cout << "Initial Investment Amount:" << endl;
		cout << "Monthly Deposit" << endl;
		cout << "Annual Interest" << endl;
		cout << "Number of Years" << endl;
		system("read -p 'Press Enter to continue...'var");
		cout << endl;
		cout << "*************************************" << endl;
		cout << "************Data Input***************" << endl;
		cout << "Initial Investment Amount: $";
		double investment, monthlydeposit, interestrate;
		int years;
		cin >> investment;
		cout << "Monthly Deposit: $";
		cin >> monthlydeposit;
		cout << "Annual Interest Rate: %";
		cin >> interestrate;
		cout << "Number of years: ";
		cin >> years;
		system("read -p 'Press Enter to continue...'var");

		savings mysavings = savings(investment, monthlydeposit, interestrate, years);
		cout << endl;

		mysavings.reportNoMonthlyDeposits();
		cout << endl;
		if (monthlydeposit > 0) {
			mysavings.reportWithMonthlyDeposits();
		}
		cout << endl << "Do you want to try another? (y/n): ";
		string choice;
		cin >> choice;
		if (choice != "y") {
			break;
		}
		cout << endl;
	}
	return 0;
}